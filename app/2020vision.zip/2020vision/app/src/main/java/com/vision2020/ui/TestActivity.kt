package com.vision2020.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.vision2020.R

class TestActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_test)
    }
}

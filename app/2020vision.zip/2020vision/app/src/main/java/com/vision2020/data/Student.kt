package com.vision2020.data

data class Student(
    var StudentName:String,
    var studentId:String,
    var isChecked:Boolean)

package com.vision2020.data

data class GroupLeader(
    var StudentName:String,
    var studentId:String,
    var leaderId:String)

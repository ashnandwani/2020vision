package com.vision2020.ui.faceDetection
import BaseFragment
import android.Manifest
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.fondesa.kpermissions.PermissionStatus
import com.fondesa.kpermissions.allGranted
import com.fondesa.kpermissions.anyPermanentlyDenied
import com.fondesa.kpermissions.anyShouldShowRationale
import com.fondesa.kpermissions.extension.permissionsBuilder
import com.fondesa.kpermissions.request.PermissionRequest
import com.google.android.exoplayer2.ui.AspectRatioFrameLayout
import com.norulab.exofullscreen.MediaPlayer
import com.norulab.exofullscreen.preparePlayer
import com.norulab.exofullscreen.setSource
import com.vision2020.R
import com.vision2020.adapter.DrugVideoAdapter
import com.vision2020.data.response.DrugList
import com.vision2020.ui.views.dialog.DrugListDialog
import com.vision2020.ui.views.dialog.ItemCallBack
import com.vision2020.utils.*
import kotlinx.android.synthetic.main.fragment_effects_on_face.*
import java.util.*
import kotlin.collections.ArrayList

class EffectsOnFaceFragment : BaseFragment<FaceViewModel>(),DrugVideoAdapter.ItemClick,
    PermissionRequest.Listener {
    private var drugList = arrayListOf<DrugList.Data>()
    private var drugName:String=""
    private var isPermission:Boolean = false
    private val request by lazy { permissionsBuilder(Manifest.permission.READ_EXTERNAL_STORAGE).build()}
    override val layoutId: Int
        get() = R.layout.fragment_effects_on_face
    override val viewModel: FaceViewModel
        get() = ViewModelProvider(this).get(FaceViewModel::class.java)
    override fun onCreateStuff() {
        progress = mContext.progressDialog(getString(R.string.request))
        request.addListener(this)
        request.send()
        MediaPlayer.initialize(mContext)
        MediaPlayer.exoPlayer?.preparePlayer(player, false)
       // MediaPlayer.exoPlayer?.setSource(mContext, "")
       // MediaPlayer.exoPlayer?.playWhenReady = false
        player.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
        //MediaPlayer.exoPlayer?.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
       // MediaPlayer.startPlayer()
        if(mContext.isAppConnected()){
            progress!!.show()
           mViewModel!!.drugList().observe(this, androidx.lifecycle.Observer {
              progress!!.dismiss()
               if(it!=null){
                   if(it.status_code == AppConstant.CODE_SUCCESS && it.data!=null){
                     drugList = it.data!!
                      editTextDrugName.setText(drugList[0].dgName)
                       if(isPermission){
                           drugName = drugList[0].dgName
                           getVideoList()
                       }
                   }else{
                       mContext.responseHandler(it.status_code,it.message)
                   }
               }else{
                   mContext.showToastMsg(getString(R.string.server_error),2)
               }
           })
        }
    }

    private fun setData() {
        if(drugList.isNotEmpty()){
            DrugListDialog(mContext,R.style.pullBottomFromTop,R.layout.dialog_options,
                drugList,"Select Drug",object: ItemCallBack.Callback{
                    override fun selected(pos: Int) {
                        editTextDrugName.setText(drugList[pos].dgName)
                        drugName = drugList[pos].dgName
                        if(isPermission){
                            getVideoList()
                        }
                       // spGroupName.setText(drugList[pos].dgName)
                       // groupId = groupList[pos].id.toString()
                        //progress!!.show()
                        //mViewModel!!.groupMembersReq(groupId)
                    }

                }).show()
        }
    }

    private fun getVideoList() {
        val videoItemHashSet = HashSet<String>()
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DATA, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.SIZE)
        val selection = MediaStore.Video.Media.DATA + " like?"
        val path = "%Drug/$drugName%"
        val selectionArgs = arrayOf("%Drug/$drugName%")
        val  videoCursor = mContext.contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection,
            selection, selectionArgs, MediaStore.Video.Media.DATE_TAKEN + " DESC")
         try {
            videoCursor!!.moveToFirst()
            do {
                videoItemHashSet.add(videoCursor.getString(videoCursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)))
            } while (videoCursor.moveToNext())
            videoCursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
             videoCursor?.close()
        }
        rvVideo.layoutManager = LinearLayoutManager(mContext)
        val downloadedList: ArrayList<String> = ArrayList(videoItemHashSet)
        Log.e("======","===list=="+downloadedList)
        val videoAdapter = DrugVideoAdapter(mContext,downloadedList,this)
        rvVideo.adapter = videoAdapter
        val list = arrayListOf<String>()
        for (value in downloadedList) {
            if (value==drugName) {
                list.add(value)
                Log.e("======","====="+list.size)
                Log.e("======","====="+value)
               // val videoAdapter = DrugVideoAdapter(mContext,list,this)
               // rvVideo.adapter = videoAdapter
            }
        }
    }

    override fun onPause() {
        super.onPause()
        MediaPlayer.pausePlayer()
       // simplePlayer!!.playWhenReady = false
    }

    override fun onDestroy() {
        MediaPlayer.stopPlayer()
       // simplePlayer!!.release()
        super.onDestroy()
    }

    override fun initListeners() {
      editTextDrugName.setOnClickListener {
          setData()
      }
    }

    override fun getPosition(path:String) {
        MediaPlayer.exoPlayer?.setSource(mContext, Uri.parse(path).toString())
        MediaPlayer.startPlayer()
    }

    override fun onPermissionsResult(result: List<PermissionStatus>) {
        when {
            result.anyPermanentlyDenied() -> mContext.showPermanentlyDeniedDialog(result)
            result.anyShouldShowRationale() -> mContext.showRationaleDialog(result, request)
            result.allGranted() -> isPermission = true
        }
    }
}
